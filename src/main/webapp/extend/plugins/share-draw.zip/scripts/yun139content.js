window.addEventListener('load', function () {

  let cookieToJson = function (arg) {
    let cookieArr = arg.split(";");
    let obj = {}
    cookieArr.forEach((i) => {
      let arr = i.split("=");
      obj[arr[0].trim()] = arr[1].trim();
    });
    return obj
  }

  let intervalId;

  let getAuthorization = function () {
    let cookieJSON = cookieToJson(this.document.cookie)
    if (cookieJSON.authorization != undefined && cookieJSON.authorization != '') {
      window.opener.postMessage(this.document.cookie, '*')
      clearInterval(intervalId);
    }
  }

  if (window.opener != null) {
    intervalId = setInterval(getAuthorization, 3000);
  }
});


